use GameMTBaseball
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4, param5) 
values('wearpart', '20001', '1', '2', '1', '�ʺ��� ��', '0', '0', '0', '0', '20001', '0', '0', '0', '0', '1', '0', '�ʺ��� �� �Դϴ�', '10', '0', '0', '0', 'Sword2_R')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4, param5) 
values('wearpart', '20002', '1', '2', '1', '����� ��', '0', '1', '0', '0', '20002', '0', '0', '0', '0', '1', '0', '����� �� �Դϴ�', '10', '0', '0', '0', 'Sword3_R')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '20100', '1', '2', '1', '�ʺ��� ������', '0', '2', '0', '0', '20100', '0', '0', '0', '0', '1', '0', '�ʺ��� ������ �Դϴ�', '10', '0', '0', '0')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '20101', '1', '2', '1', '������ ������', '0', '0', '0', '0', '20101', '0', '0', '0', '0', '1', '0', '������ ������ �Դϴ�', '25', '0', '0', '0')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '20200', '1', '2', '1', '�ʺ��� Ȱ', '0', '1', '0', '0', '20200', '0', '0', '0', '0', '1', '0', '�ʺ��� Ȱ �Դϴ�', '25', '0', '0', '0')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '20201', '1', '2', '1', '����� Ȱ', '0', '2', '0', '0', '20201', '0', '0', '0', '0', '1', '0', '����� Ȱ �Դϴ�', '25', '0', '0', '0')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '21001', '1', '0', '1', '���谡 ���', '0', '0', '0', '0', '21001', '0', '0', '0', '0', '1', '0', '���谡 ��� �Դϴ�', '0', '10', '0', '0')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '21002', '1', '0', '1', '���� ���', '0', '0', '0', '0', '21002', '0', '0', '0', '0', '1', '0', '���� ��� �Դϴ�', '0', '0', '0', '50')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '22001', '1', '1', '1', '���谡 ����', '0', '0', '0', '0', '22001', '0', '0', '0', '0', '1', '0', '���谡 ���� �Դϴ�', '10', '0', '0', '0')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '22002', '1', '1', '1', '���� ����', '0', '0', '0', '0', '22002', '0', '0', '0', '0', '1', '0', '���� ���� �Դϴ�', '0', '10', '0', '0')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '23001', '1', '3', '1', '���谡 �Ź�', '0', '0', '0', '0', '23001', '0', '0', '0', '0', '1', '0', '���谡 �Ź� �Դϴ�', '0', '0', '0', '50')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '23002', '1', '3', '1', '���� �Ź�', '0', '0', '0', '0', '23002', '0', '0', '0', '0', '1', '0', '���� �Ź� �Դϴ�', '10', '0', '0', '0')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '300', '1', '3', '1', '����1', '0', '0', '0', '0', '300', '0', '0', '0', '0', '1', '0', '����1 �Դϴ�', '-1', '0', '0', '0')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '301', '1', '3', '1', '����2', '0', '0', '1', '0', '301', '0', '0', '0', '0', '1', '0', '����2 �Դϴ�', '4100', '1', '0', '0')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '302', '1', '3', '1', '����3', '0', '0', '2', '0', '302', '0', '0', '0', '0', '1', '0', '����3 �Դϴ�', '4101', '1', '0', '0')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '303', '1', '3', '1', '����4', '0', '0', '3', '0', '303', '0', '0', '0', '0', '1', '0', '����4 �Դϴ�', '4102', '1', '0', '0')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '304', '1', '3', '1', '����5', '0', '0', '4', '0', '304', '0', '0', '0', '0', '1', '0', '����5 �Դϴ�', '4103', '1', '0', '0')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3, param4) 
values('wearpart', '305', '1', '3', '1', '����6', '0', '0', '5', '0', '305', '0', '0', '0', '0', '1', '0', '����6 �Դϴ�', '4104', '1', '0', '0')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2) 
values('usepart', '10001', '2', '40', '3', '���� ����', '1', '0', '1', '0', '10001', '0', '0', '0', '0', '1', '0', 'HP�� 100ȸ��', '100', '0')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2) 
values('usepart', '10002', '2', '40', '3', '�Ķ� ����', '1', '0', '2', '0', '10002', '0', '0', '0', '1', '1', '0', 'MP�� 100ȸ��', '0', '100')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description) 
values('coinpart', '30001', '4', '30', '3', '��ȭ', '1', '0', '1', '0', '30001', '0', '0', '1', '0', '1', '0', '��ȭ')
GO

insert into dbo.tItemInfo(labelname, itemcode, category, subcategory, equpslot, itemname, activate, toplist, grade, discount, icon, playerlv, multistate, gamecost, cashcost, buyamount, sellcost, description, param1, param2, param3) 
values('etcpart', '40001', '3', '510', '60', '��Ÿ��1', '0', '0', '1', '0', '40001', '0', '0', '0', '0', '1', '1', '��Ÿ��1', '10', '4000', '1')
GO

